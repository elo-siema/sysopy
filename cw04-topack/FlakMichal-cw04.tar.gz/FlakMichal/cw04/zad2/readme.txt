make all produkuje main.o.
Przykładowe wywołanie:
./main.o -L 10000 --Type 2