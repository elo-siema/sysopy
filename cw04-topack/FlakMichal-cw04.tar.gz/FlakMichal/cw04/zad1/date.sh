#!/bin/sh
while true
do
	date
	sleep 1
done