make all produkuje main.o.
Przykładowe wywołanie:
./main.o