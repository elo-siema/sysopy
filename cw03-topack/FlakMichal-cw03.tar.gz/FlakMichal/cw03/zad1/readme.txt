make all produkuje main.o.
Przykładowe wywołanie:
./main.o / '<' 1996/06/29