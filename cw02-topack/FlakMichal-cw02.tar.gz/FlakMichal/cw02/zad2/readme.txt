make all produkuje nftw.o oraz stat.o, dwie wersje opisanego programu.
Przykładowe wywołanie:
./nftw.o / '<' 1996/06/29